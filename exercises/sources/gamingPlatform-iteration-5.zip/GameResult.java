package com.fhnw.exercise.gameplatform.increment5;

public class GameResult {
	private User winner = null;
	private User opponent = null;
	private int duration = 0;
	private int points = 0;
	
	// constructor
	public GameResult(User winner, User opponent, int duration, int points) {
		this.winner = winner;
		this.opponent = opponent;
		this.duration = duration;
		this.points = points;
	}
	
	// getter and setter methods
	public User getWinner() {
		return winner;
	}
	public int getDuration() {
		return duration;
	}
	public int getPoints() {
		return points;
	}
		public String toString() {
		return "game result := " + winner + " won against " + opponent + " (duration " + duration + ", points " + points + ")";
	}
}
