package com.fhnw.exercise.gameplatform.increment5;

public class MyGame implements Game {
	private String name = null;
	private static int MAX = 100;
	private static int MIN = 0;
	private HighScore hs = null;

	// constructor
	public MyGame(GameName name) {
		this.name = name.toString();
		hs = new HighScore(this.name);
	}
	
	// instance methods
	public void registerAsFavourite(FavouriteList list) {
		list.registerGame(this);
	}
	public void launch(User user) {
		User deviceUser = new MyUser("Computer","Laptop","Computer","cmp",Role.DEVICE);
		User u = null;
		User uo = null;

		// Randomise game results (points and duration)
		int duration = (int) Math.floor(Math.random() * (MAX-MIN + 1) + MIN);
		int points = (int) Math.floor(Math.random() * (MAX-MIN + 1) + MIN);
		// Randomise game results toggling between human and computer user
		if(Math.floor(Math.random() * (MAX-MIN + 1) + MIN) > (MAX / 2)) {
			u = deviceUser;
			uo = user;
		} else {
			u = user;
			uo = deviceUser;
		}
		
		GameResult gr = new GameResult(u, uo, duration, points);
		hs.add(gr);
	}

	// getter and setter methods
	public String getName() {
		return name;
	}
	public String toString() {
		return "game := " + name;
	}
	public HighScore getHighScore() {
		return hs;
	}
}
