package com.fhnw.exercise.gameplatform.increment5.workflow;

import com.fhnw.exercise.gameplatform.increment5.Game;
import com.fhnw.exercise.gameplatform.increment5.GameName;
import com.fhnw.exercise.gameplatform.increment5.MyGame;

public class Driver {
	public static void main(String[] args) {
		Game game = new MyGame(GameName.TICTACTOE);
		WFMessage msg = new WFMessage(game.getName(),game);
		
		WFBrancher wfCondBrancher = new WFConditionalBrancher();
		WFBroadcaster wfMultiplexer = new WFMultiplexer();
		WFTask wfParControl = new WFParControl();
		WFTask wfCodeCheck = new WFCodeCheck();
		WFEnd wfEnd = new WFEnd();
		
		WFStart wfStart = new WFStart();
		
		wfMultiplexer.addNext(wfParControl);
		wfParControl.setNext(wfEnd);
		wfCondBrancher.setTrueBranch(wfEnd);
		wfCondBrancher.setFalseBranch(wfCodeCheck);
		wfCodeCheck.setNext(wfEnd);
		wfMultiplexer.addNext(wfCondBrancher);
		
		wfStart.registerWF(wfMultiplexer);
		wfStart.runWF(msg);
		
		System.out.println("Authorization result of the entire workflow is " + wfEnd.isAuthorized());
	}
}
