package com.fhnw.exercise.gameplatform.increment5.workflow;

import java.util.HashMap;
import java.util.Map;

import com.fhnw.exercise.gameplatform.increment5.Game;

public class WFMessage {
	private boolean isAuthorized = false;
	private Map<String, String> header = new HashMap<>();
	private Game game = null;
	
	// constructor
	public WFMessage(String gName, Game game) {
		this.game = game;
		header.put("Name", gName);
	}
	
	// methods
	public void authorize() {
		isAuthorized = true;
	}
	public void deAuthorize() {
		isAuthorized = false;
	}
	
	// getter and setter methods
	public Map<String, String> getHeader() {
		return header;
	}
	public Game getBody() {
		return game;
	}
	public boolean getIsAuthorized() {
		return isAuthorized;
	}
}
