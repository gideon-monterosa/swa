package com.fhnw.exercise.gameplatform.increment5.workflow;

import java.util.ArrayList;
import java.util.List;

public class WFEnd implements WFBuildingBlock {
	List<WFMessage> receivedMessages = new ArrayList();
	public void execute(WFMessage msg) {
		receivedMessages.add(msg);
	}
	public boolean isAuthorized() {
		boolean result = true;
		
		// all tasks must have authorized the new game
		for(int i=0;i<receivedMessages.size();i++) {
			if(!receivedMessages.get(i).getIsAuthorized()) {
				result = false;
				break;
			}
		}
		return result;
	}
}
