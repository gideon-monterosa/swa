package com.fhnw.exercise.gameplatform.increment5.workflow;

public class WFStart {
	private WFBuildingBlock wf = null;
	public void registerWF(WFBuildingBlock wf) {
		this.wf = wf;
	}
	public void runWF(WFMessage m) {
		if(wf != null) {
			wf.execute(m);
		}
	}
}
