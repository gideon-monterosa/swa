package com.fhnw.exercise.gameplatform.increment5.workflow;

public abstract class WFTask implements WFBuildingBlock {
	protected WFBuildingBlock next = null;

	public void setNext(WFBuildingBlock next) {
		this.next = next;
	}
	public abstract void execute(WFMessage msg);
}
