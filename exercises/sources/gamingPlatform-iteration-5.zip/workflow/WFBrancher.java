package com.fhnw.exercise.gameplatform.increment5.workflow;

public abstract class WFBrancher implements WFBuildingBlock {
	protected WFBuildingBlock trueBranch = null;
	protected WFBuildingBlock falseBranch = null;
	
	public void setTrueBranch(WFBuildingBlock t) {
		trueBranch = t;
	}
	public void setFalseBranch(WFBuildingBlock f) {
		falseBranch = f;
	}
	public abstract void execute(WFMessage msg);
}
