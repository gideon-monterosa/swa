package com.fhnw.exercise.gameplatform.increment5.workflow;

import java.util.Map;

import com.fhnw.exercise.gameplatform.increment5.Game;

public class WFMultiplexer extends WFBroadcaster {
	public void execute(WFMessage msg) {
		System.out.println("perform multiplexing");
		for(int i=0;i<next.size();i++) {
			next.get(i).execute(msg);
		}
	}
}
