package com.fhnw.exercise.gameplatform.increment5.workflow;

import java.util.Map;

import com.fhnw.exercise.gameplatform.increment5.Game;

public class WFCodeCheck extends WFTask {
	public void execute(WFMessage msg) {
		Game game = msg.getBody();
		Map<String, String> map = msg.getHeader();
		msg.authorize();
		System.out.println("Reviewed and authorized " + game + " from code check perspective");
		
		if(next != null) {
			next.execute(msg);
		}
	}
}
