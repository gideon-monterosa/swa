package com.fhnw.exercise.gameplatform.increment5.workflow;

public interface WFBuildingBlock {
	public void execute(WFMessage msg);
}
