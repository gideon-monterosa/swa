package com.fhnw.exercise.gameplatform.increment5.workflow;

import java.util.ArrayList;
import java.util.List;

public abstract class WFBroadcaster implements WFBuildingBlock {
	protected List<WFBuildingBlock> next = new ArrayList<> ();

	public void addNext(WFBuildingBlock next) {
		this.next.add(next);
	}
	public abstract void execute(WFMessage msg);
}
