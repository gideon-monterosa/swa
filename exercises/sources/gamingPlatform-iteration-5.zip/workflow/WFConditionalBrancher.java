package com.fhnw.exercise.gameplatform.increment5.workflow;

import java.util.Map;

import com.fhnw.exercise.gameplatform.increment5.Game;
import com.fhnw.exercise.gameplatform.increment5.GameName;

public class WFConditionalBrancher extends WFBrancher {
	public void execute(WFMessage msg) {
		Game game = msg.getBody();
		Map<String, String> map = msg.getHeader();
		System.out.println("perform conditional branching");

		String gName = game.getName();
		if(gName.equals(GameName.CHESS.toString())) {
			trueBranch.execute(msg);
		} else {
			falseBranch.execute(msg);
		}
	}
}
