package com.fhnw.exercise.gameplatform.increment5;

public enum Role {
	PLAYER, ADMIN, DEVICE
}
