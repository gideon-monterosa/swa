package com.fhnw.exercise.gameplatform.increment5;

public interface FavouriteList {
	public Game selectGame(GameName gameName);
	public void registerGame(Game game);
	public void display();
}
