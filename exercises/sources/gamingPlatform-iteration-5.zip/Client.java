package com.fhnw.exercise.gameplatform.increment5;

public class Client {
	public static void main(String[] args) {
		GamePlatform gp = GamePlatform.getGamePlatform();
		
		// register new user with game platform
		gp.registerUser("Ingo", "Arnold", "ai1", "test", "test", Role.PLAYER);
		gp.registerUser("Jonas", "Arnold", "aj1", "pwd", "pwd", Role.PLAYER);
		gp.registerUser("Luis", "Arnold", "al1", "secret", "secret", Role.ADMIN);

		// show registered users
		gp.displayUserManagement();
		
		// login user and establish user session
		User userIngo = gp.loginUser("ai1", "test");
		User userJonas = gp.loginUser("aj1", "pwd");
		User userLuis = gp.loginUser("al1", "secret");

		// games are instantiated
		Game game1 = new MyGame(GameName.TICTACTOE);
		Game game2 = new MyGame(GameName.CHESS);
		Game game3 = new MyGame(GameName.CONNECT4);

		// add games to game platform
		gp.addGame(game1, userLuis);
		gp.addGame(game2, userLuis);
		gp.addGame(game3, userLuis);
		
		// browse game catalogue
		GameCatalogue gc = gp.getGameCatalogue();
		gc.display();

		// user Ingo
		// add games to user's favourites list 
		gc.selectGame(GameName.TICTACTOE, userIngo);
		gc.selectGame(GameName.CHESS, userIngo);
		
		// select game from user's favourites list and launch game
		userIngo.getFavoriteList().display();
		Game game = userIngo.getFavoriteList().selectGame(GameName.TICTACTOE);
		game.launch(userIngo);
		
		game = userIngo.getFavoriteList().selectGame(GameName.CHESS);
		game.launch(userIngo);

		// user Jonas
		// add games to user's favourites list
		gc.selectGame(GameName.CONNECT4, userJonas);
		
		// select game from user's favourites list and launch game
		userJonas.getFavoriteList().display();
		game = userJonas.getFavoriteList().selectGame(GameName.CONNECT4);
		game.launch(userJonas);

		// user Luis
		// add games to user's favourites list
		gc.selectGame(GameName.TICTACTOE, userLuis);
		gc.selectGame(GameName.CHESS, userLuis);
		gc.selectGame(GameName.CONNECT4, userLuis);
		
		// select game from user's favourites list and launch game
		userLuis.getFavoriteList().display();
		game = userLuis.getFavoriteList().selectGame(GameName.CONNECT4);
		game.launch(userLuis);

		game = userLuis.getFavoriteList().selectGame(GameName.CHESS);
		game.launch(userLuis);

		game = userLuis.getFavoriteList().selectGame(GameName.TICTACTOE);
		game.launch(userLuis);

		// Luis views high scores of all three games
		game = userLuis.getFavoriteList().selectGame(GameName.CONNECT4);
		game.getHighScore().display();
		game = userLuis.getFavoriteList().selectGame(GameName.CHESS);
		game.getHighScore().display();
		game = userLuis.getFavoriteList().selectGame(GameName.TICTACTOE);
		game.getHighScore().display();
	}
}


