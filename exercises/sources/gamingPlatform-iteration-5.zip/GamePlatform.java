package com.fhnw.exercise.gameplatform.increment5;

public class GamePlatform {
	private static GamePlatform singleton = null;
	
	// singleton factory
	private GamePlatform() {}
	public static GamePlatform getGamePlatform() {
		if(singleton == null)
			singleton = new GamePlatform();
		return singleton;
	}
	
	// instance methods
	public void registerUser(String name, String surname, String uniqueId, String pwd1, String pwd2, Role role) {
		UserManagement um = UserManagement.getUserManagement();
		if(pwd1.contentEquals(pwd2)) {
			User u = new MyUser(name,surname,uniqueId,pwd1,role);
			um.addUser(u);
		}
	}
	public void addGame(Game game, User user) {
		// is user authenticated?
		if (user != null) {
			// does user have admin role?
			if (user.getRole().equals(Role.ADMIN)) {
				GameCatalogue gc = GameCatalogue.getGameCatalogue();
				gc.add(game);
			}
		}
	}
	public User loginUser(String uniqueId, String pwd) {
		UserManagement um = UserManagement.getUserManagement();
		User u = um.authN(uniqueId, pwd);
		return u;
	}
	public void displayUserManagement() {
		UserManagement um = UserManagement.getUserManagement();
		um.display();
	}
	// getter and setter methods
	public GameCatalogue getGameCatalogue() {
		return GameCatalogue.getGameCatalogue();
	}
}
