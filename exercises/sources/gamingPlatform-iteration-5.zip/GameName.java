package com.fhnw.exercise.gameplatform.increment5;

public enum GameName {
	TICTACTOE, CHESS, CONNECT4
}
