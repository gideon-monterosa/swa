package com.fhnw.exercise.gameplatform.increment5;

public interface Game {
	public void registerAsFavourite(FavouriteList list);
	public void launch(User user);
	public String getName();
	public HighScore getHighScore();
}
