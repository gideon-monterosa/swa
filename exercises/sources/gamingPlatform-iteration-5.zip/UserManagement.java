package com.fhnw.exercise.gameplatform.increment5;

import java.util.ArrayList;
import java.util.List;

public class UserManagement {
	private List<User> users = new ArrayList<User>();
	private static UserManagement singleton = null;
	
	// singleton pattern
	public static UserManagement getUserManagement() {
		if(singleton == null)
			singleton = new UserManagement();
		return singleton;
	}
	
	// instance methods
	public User exists(String uniqueId) {
		User u = null;
		boolean result = false;
		
		for(int i=0;i<users.size();i++) {
			u = users.get(i);
			result = u.getUniqueId().contentEquals(uniqueId);
			if(result == true)
				break; 
			else
				u = null;
		}
		return u;
	}
	public void addUser(User user) {
		users.add(user);
	}
	public User authN(String uniqueId, String pwd) {
		boolean b = false;

		User u = exists(uniqueId);
		
		if(u != null) {
			b = u.getPwd().contentEquals(pwd);
			if(b != true) {
				u = null;
			}
		}
		return u;
	}
	public void display() {
		System.out.println("Registered users");
		for(int i=0;i<users.size();i++) {
			User user = users.get(i);
			System.out.println(user);
		}
	}
}
