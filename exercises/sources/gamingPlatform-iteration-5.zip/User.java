package com.fhnw.exercise.gameplatform.increment5;

public interface User {
	public String getUniqueId();
	public String getPwd();
	public FavouriteList getFavoriteList();
	public Role getRole();
}
