package com.fhnw.exercise.gameplatform.increment5;

import java.util.ArrayList;
import java.util.List;

import com.fhnw.exercise.gameplatform.increment5.workflow.WFBrancher;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFBroadcaster;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFCodeCheck;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFConditionalBrancher;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFEnd;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFMessage;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFMultiplexer;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFParControl;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFStart;
import com.fhnw.exercise.gameplatform.increment5.workflow.WFTask;

public class GameCatalogue {
	private static GameCatalogue singleton = null;
	private List<Game> catalogue = null;
	
	// singleton factory
	private GameCatalogue() {
		catalogue = new ArrayList<Game>();
	}
	public static GameCatalogue getGameCatalogue() {
		if(singleton == null)
			singleton = new GameCatalogue();
		return singleton;
	}
	public void add(Game game) {
		WFMessage msg = new WFMessage(game.getName(),game);
		
		WFBrancher wfCondBrancher = new WFConditionalBrancher();
		WFBroadcaster wfMultiplexer = new WFMultiplexer();
		WFTask wfParControl = new WFParControl();
		WFTask wfCodeCheck = new WFCodeCheck();
		WFEnd wfEnd = new WFEnd();
		
		WFStart wfStart = new WFStart();
		
		wfMultiplexer.addNext(wfParControl);
		wfParControl.setNext(wfEnd);
		wfCondBrancher.setTrueBranch(wfEnd);
		wfCondBrancher.setFalseBranch(wfCodeCheck);
		wfCodeCheck.setNext(wfEnd);
		wfMultiplexer.addNext(wfCondBrancher);
		
		wfStart.registerWF(wfMultiplexer);
		
		System.out.println("Run game-registration workflow ...");
		wfStart.runWF(msg);
		
		if (wfEnd.isAuthorized()) {
			catalogue.add(game);
		}
	}

	// instance methods
	public Game selectGame(GameName gameName, User user) {
		Game g = null;
		boolean result = false;
		
		// is user authenticated?
		if(user != null) {
			for(int i=0;i<catalogue.size();i++) {
				g = catalogue.get(i);
				result = g.getName().contentEquals(gameName.toString());
				if(result == true)
					break;
				else
					g = null;
			}
			if(g != null) {
				g.registerAsFavourite(user.getFavoriteList());
			}
		}
		return g;
	}
	public void display() {
		System.out.println("Registered games");
		for(int i=0;i<catalogue.size();i++) {
			Game game = catalogue.get(i);
			System.out.println(game);
		}	
	}
}
