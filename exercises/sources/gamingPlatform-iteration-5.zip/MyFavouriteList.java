package com.fhnw.exercise.gameplatform.increment5;

import java.util.ArrayList;
import java.util.List;

public class MyFavouriteList implements FavouriteList {
	private List<Game> games = null;
	private User user = null;
	
	// constructor
	public MyFavouriteList(User user) {
		this.user = user;
		games = new ArrayList<Game>();
	}
	
	// instance methods
	public Game selectGame(GameName gameName) {
		boolean result = false;
		Game g = null;
		
		// is user authenticated?
		if(user != null) {
			for(int i=0;i<games.size();i++) {
				g = games.get(i);
				result = g.getName().contentEquals(gameName.toString());
				if(result == true)
					break;
				else
					g = null;
			}
		}
		return g;
	}
	public void registerGame(Game game) {
		games.add(game);
	}
	public void display() {
		System.out.println("Favorites of " + user);
		for(int i=0;i<games.size();i++) {
			Game game = games.get(i);
			System.out.println(game);
		}
	}
}
