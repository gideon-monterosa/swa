package com.fhnw.exercise.gameplatform.increment5;

public class MyUser implements User {
	private FavouriteList favouriteList = null;
	private String name = null;
	private String surName = null;
	private Role role = null;
	private String pwd = null;
	private String uniqueId = null;
	
	// constructor
	public MyUser(String name, String surname, String uniqueId, String pwd, Role role) {
		favouriteList = new MyFavouriteList(this);
		this.name = name;
		this.surName = surname;
		this.role = role;
		this.pwd = pwd;
		this.uniqueId = uniqueId;
	}
	
	// getter and setter methods
	public FavouriteList getFavoriteList() {
		return favouriteList;
	}
	public Role getRole() {
		return role;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public String getPwd() {
		return pwd;
	}
	public String toString() {
		return name + " " + surName + " (" + uniqueId + ") [role = " + role + "]";
	}
}
