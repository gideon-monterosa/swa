package com.fhnw.exercise.gameplatform.increment5;

import java.util.ArrayList;
import java.util.List;

public class HighScore  {
	private List<GameResult> list = null;
	private String gName = null;

	public HighScore(String gName) {
		list = new ArrayList<GameResult>();
		this.gName = gName;
	};

	public void add(GameResult result) {
		list.add(result);
	}

	public void display() {
		System.out.println("High score of " + gName);
		for(int i=0;i<list.size();i++) {
			GameResult gameResult = list.get(i);
			System.out.println(gameResult);
		}
	}
}
